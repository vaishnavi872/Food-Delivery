import express from "express";
const router = express.Router();

// Place Order Endpoint
router.post("/place", (req, res) => {
  const { address, items, amount } = req.body;

  if (!address || !items || !amount) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  const { firstName, lastName, email, street, city, state, phone } = address;

  if (!firstName || !email || !street || !city || !state || !phone) {
    return res.status(400).json({ message: "Missing required address fields" });
  }

  console.log("✅ Order received:", req.body);

  // In a real app, save to DB here
  res.status(200).json({ message: "Order placed successfully!" });
});

export default router;



