import React, { useContext, useState } from 'react';
import './PlaceOrder.css';
import { StoreContext } from '../../Context/StoreContext';
import axios from 'axios';

const PlaceOrder = () => {
  const { getTotalCartAmount, token, food_list, cartIems, url } = useContext(StoreContext);

  const [data, setData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    street: "",
    city: "",
    state: "",
    zipcode: "",
    country: "",
    phone: ""
  });

  const onChangeHandler = (event) => {
    const { name, value } = event.target;
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handlePlaceOrder = async (event) => {
    event.preventDefault();
    try {
      let orderItems = [];

      food_list?.forEach((item) => {
        if (!item || !item._id) return;

        const quantity = cartIems?.[item._id];

        if (quantity && quantity > 0) {
          orderItems.push({
            ...item,
            quantity
          });
        }
      });

      const subtotal = getTotalCartAmount() || 0;
      const deliveryFee = subtotal === 0 ? 0 : 2;
      const totalAmount = subtotal + deliveryFee;

      const orderData = {
        address: data,
        items: orderItems,
        amount: totalAmount,
      };

      const response = await axios.post(`${url}/api/order/place`, orderData, {
        headers: { token }
      });

      if (response.status === 200) {
        alert("✅ Order placed successfully!");
        // Optionally: clear cart or redirect
      } else {
        alert("Something went wrong. Please try again.");
      }

    } catch (error) {
      console.error("Order placement failed:", error);
      alert("Failed to place order. Please check your connection or try again.");
    }
  };

  // Safe values for cart totals
  const subtotal = getTotalCartAmount() || 0;
  const deliveryFee = subtotal === 0 ? 0 : 2;
  const total = subtotal + deliveryFee;

  return (
    <form onSubmit={handlePlaceOrder} className='place-order'>
      <div className='place-order-left'>
        <p className='title'>Delivery Information</p>
        <div className='multi-fields'>
          <input name="firstName" onChange={onChangeHandler} value={data.firstName} type='text' placeholder='First Name' required />
          <input name="lastName" onChange={onChangeHandler} value={data.lastName} type='text' placeholder='Last Name' required />
        </div>
        <input name='email' onChange={onChangeHandler} value={data.email} type='email' placeholder='Email address' required />
        <input name='street' onChange={onChangeHandler} value={data.street} type='text' placeholder='Street' required />
        <div className='multi-fields'>
          <input name='city' onChange={onChangeHandler} value={data.city} type='text' placeholder='City' required />
          <input name='state' onChange={onChangeHandler} value={data.state} type='text' placeholder='State' required />
        </div>
        <div className='multi-fields'>
          <input name='zipcode' onChange={onChangeHandler} value={data.zipcode} type='text' placeholder='Zip code' required />
          <input name='country' onChange={onChangeHandler} value={data.country} type='text' placeholder='Country' required />
        </div>
        <input
          name='phone'
          onChange={onChangeHandler}
          value={data.phone}
          type='tel'
          pattern='[0-9]{10}'
          placeholder='Phone (10 digits)'
          required
        />
      </div>

      <div className='place-order-right'>
        <div className='cart-total'>
          <h2>Cart Totals</h2>
          <div>
            <div className='cart-total-details'>
              <p>Subtotal</p>
              <p>${subtotal}</p>
            </div>
            <hr />
            <div className='cart-total-details'>
              <p>Delivery Fee</p>
              <p>${deliveryFee}</p>
            </div>
            <hr />
            <div className='cart-total-details'>
              <p>Total</p>
              <p>${total}</p>
            </div>
          </div>
          <button type='submit'>PROCEED TO PAYMENT</button>
        </div>
      </div>
    </form>
  );
};

export default PlaceOrder;

