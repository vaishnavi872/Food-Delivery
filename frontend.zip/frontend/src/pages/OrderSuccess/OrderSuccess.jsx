import React from 'react';

const OrderSuccess = () => {
  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>✅ Order Successful</h1>
      <p>Thank you for your purchase! Your order is confirmed.</p>
    </div>
  );
};

export default OrderSuccess;


