import React from 'react';

const Cancel = () => (
  <div style={{ textAlign: 'center', padding: '2rem' }}>
    <h2>❌ Payment Cancelled</h2>
    <p>Your payment was cancelled. You can try again anytime.</p>
  </div>
);

export default Cancel;
