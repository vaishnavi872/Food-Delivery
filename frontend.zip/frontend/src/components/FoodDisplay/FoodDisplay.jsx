import React, { useContext, useState } from 'react'
import './FoodDisplay.css'
import { StoreContext } from '../../Context/StoreContext'
import FoodItem from '../FoodItem/FoodItem'

const FoodDisplay = ({ category }) => {
  const { food_list } = useContext(StoreContext);

  const [food_list2, setFoodList2] = useState(food_list);
  return (
    <div className="food-display " id="food-display">
      <h2>Top dishes near you</h2>
      <div className="food-display-list">
        {food_list2.map((item, index) => {
          if (category === "All" || category === item.category) {
            return (
              <FoodItem
                key={index}
                id={item.id}
                name={item.name}
                description={item.description}
                price={item.price}
                image={item.image}
                cartCount={item?.cartCount}
                onChangeCount={(count) => {

                  let list = [];
                  let cartList=[]

                  food_list2.map((item1, index1) => {
                    if (item._id === item1._id) {
                      list.push({
                        _id: item1._id,
                        name: item1.name,
                        image: item1.image,
                        price: item1.price,
                        description: item1.description,
                        category: item1.category,
                        cartCount:
                          count == "+"
                            ? item1?.cartCount + 1
                            : item1?.cartCount - 1,
                      });
                      
                      if(count == "+"){
                        cartList.push(list[list.length-1])
                      // }else if(count == "-"){
                        // cartList.push(list[list.length-1])
                      }

                    } else {
                      list.push(item1);

                      if(item1.cartCount>0){
                        cartList.push(list[list.length-1])
                      // }else if(count == "-"){
                        // cartList.push(list[list.length-1])
                      }
                    }
                  });


                  console.log('cartList :: ',cartList)
                  localStorage.setItem('cartdata',JSON.stringify(cartList))

                  setFoodList2(list);
                }}
              />
            );
          }
        })}
      </div>
    </div>
  );
};

export default FoodDisplay;