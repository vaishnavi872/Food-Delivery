import { createContext, useEffect, useState } from "react";
import axios from "axios"; // ✅ MISSING IMPORT
import { food_list } from "../assets/assets";

export const StoreContext = createContext(null);

const StoreContextProvider = (props) => {
  const [cartItems, setCartItems] = useState({});
  const url = "http://localhost:4000";
  const [token, setToken] = useState("");

  const addToCart = async (itemId) => {
    if (!cartItems[itemId]) {
      setCartItems((prev) => ({ ...prev, [itemId]: 1 }));
    } else {
      setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }));
    }

    if (token) {
      await axios.post(`${url}/api/cart/add`, { itemId }, { headers: { token } });
    }
  };

  const removeFromCart = async (itemId) => {
    let cartList = JSON.parse(localStorage.getItem("cartdata")) || [];

    if (token) {
      await axios.post(`${url}/api/cart/remove`, { itemId }, { headers: { token } });
    }

    // Filter out the item to be removed
    let updatedCart = cartList.filter((item) => item._id !== itemId);

    // Update localStorage
    localStorage.setItem("cartdata", JSON.stringify(updatedCart));

    // Set cartItems (you may want to refactor this depending on how cartItems is used)
    setCartItems(updatedCart);
  };

  const getTotalCartAmount = () => {
    let cartList = JSON.parse(localStorage.getItem("cartdata")) || [];
    let total = 0;

    cartList.forEach((item) => {
      total += item.price * item.cartCount;
    });

    return total;
  };

  const loadCartData = async (token) => {
    try {
      const response = await axios.post(`${url}/api/cart/get`, {}, { headers: { token } });
      setCartItems(response.data.cartData);
    } catch (error) {
      console.error("Failed to load cart data:", error);
    }
  };

  useEffect(() => {
    async function loadData() {
      if (localStorage.getItem("token")) {
        const savedToken = localStorage.getItem("token");
        setToken(savedToken);
        await loadCartData(savedToken);
      }
    }
    loadData(); // ✅ THIS WAS MISSING
  }, []);

  const contextValue = {
    food_list,
    cartItems,
    setCartItems,
    addToCart,
    removeFromCart,
    getTotalCartAmount,
    url,
    token,
    setToken,
  };

  return (
    <StoreContext.Provider value={contextValue}>
      {props.children}
    </StoreContext.Provider>
  );
};

export default StoreContextProvider;

