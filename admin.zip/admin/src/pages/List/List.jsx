import React, { useEffect, useState } from 'react'
import './List.css'
import axios from 'axios';
import { toast } from 'react-toastify';


const List = ({url}) => {
 
  

  const[list,setList] = useState([]);

  const fetchList = async () =>{
    const response = await axios.get(`${url}/api/food/list`);
   // console.log('response :: ',response.data.data)
    setTimeout(() => {
    if (response?.data?.data) {
      setList(response?.data?.data)
    } else {
      toast.error("Error")
    }
    }, 0.1000);

  }

  const removeFood = async (id) => {
    try {
      const response = await fetch(`${url}/api/food/remove/${id}`, {
        method: "DELETE",
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete");
      }
  
      toast.success("Food item deleted successfully!");
      setList(prevList => prevList.filter(item => item._id !== id)); // Update UI
    } catch (error) {
      console.error("Error removing food:", error.message);
      toast.error("Failed to delete food.");
    }
  };
  

  useEffect(()=> {
    fetchList();
  },[])

  return (
    <div className='list add flex-col'>
    <p>All Foods List</p>
    <div className='list-table'>
      <div className='list-table-format title'>
        <b>Image</b>
        <b>Name</b>
        <b>Category</b>
        <b>Price</b>
        <b>Action</b>
      </div>
      {list.map((item,index)=>{
        return (
          <div  key={index} className='list-table-format'>
          <img src={`http://localhost:4000/uploads/${item.image}`} alt={item.name} width="100" />
            <p>{item.name}</p>
            <p>{item.category}</p>
            <p>${item.price}</p>
            <button onClick={()=>removeFood(item._id)} className='cursor'>❌</button>
          </div>
        )
      })}
    </div>


    </div>
  )
}

export default List